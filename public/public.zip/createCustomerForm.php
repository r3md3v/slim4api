<!DOCTYPE html>
<html>
  <head>
    <title>Slim4API</title>
    <link href="css/favicon.ico" rel="icon" />
    <link href="css/slim4api.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="js/veriform.js"></script>
  </head>
  <body>
    <div class="flex-container">
    <div class="container">

    <h1>Slim4API - Customer Create</h1>

    <form method="post" class="form" action="/customers"
            onsubmit="return verifForm([cusname,address,city,email],'Error : fields marked with an asterisk are mandatory!') && validateEmail(email,'Error : email format invalid!');">

        <p>
            <label for="cusname">* Name:</label><br />
            <input type="text" class="form" name="cusname" placeholder="Name" /><br />

            <label for="address">* Address:</label><br />
            <input type="text" class="form" name="address" placeholder="Address" /><br />

            <label for="city">* City:</label><br />
            <input type="text" class="form" name="city" placeholder="City" /><br />

            <label for="phone">Phone:</label><br />
            <input type="text" class="form" name="phone" placeholder="Phone number" /><br />

            <label for="email">* Email:</label><br />
            <input type="email" class="form" name="email" placeholder="email.me@domain.com" /><br />

            <br />
        
            <button>Save</button>
        </p>
    </form>
    </div>
    </div>
  </body>
</html>